import React from "react";

const cartListItem = ({ product, removeFromCart }) => {
  return (
    <li>
      <p>{product.name}</p>
      <p>{product.price}</p>
      <button type="button" onClick={() => removeFromCart(product.id)}>
        Delete
      </button>
    </li>
  );
};

export default cartListItem;
