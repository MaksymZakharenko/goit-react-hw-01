import React from "react";
import CartListItem from "./cartListItem/CartListItem.js";

const CartList = ({ cart, removeFromCart, removeAllFromCart }) => {
  return (
    <>
      {cart.length > 0 ? (
        <>
          <ul>
            {cart.map((product) => (
              <CartListItem
                product={product}
                key={product.id}
                removeFromCart={removeFromCart}
              />
            ))}
          </ul>
          <button type="button" onClick={removeAllFromCart}>
            Оформить заказ
          </button>
        </>
      ) : (
        <p>No feedback given!</p>
      )}
    </>
  );
};

export default CartList;
