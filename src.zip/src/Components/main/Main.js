import React, { Component } from "react";
import data from "../../data";
import CartList from "../cartList/CartList";
// import LaptopList from "../laptopList/LaptopList";
import PhoneList from "../phoneList/PhoneList";

console.dir(Component);

class Main extends Component {
  state = {
    cart: [],
  };
  // основной способ добавления
  addToCart = (product) => {
    this.setState((prevState) => ({ cart: [...prevState.cart, product] }));
  };

  // основной способ удаления
  removeFromCart = (id) =>
    this.setState((prevState) => ({
      cart: [...prevState.cart.filter((product) => product.id !== id)],
    }));

  // основной способ обнуления

  removeAllFromCart = () => this.setState({ cart: [] });

  render() {
    return (
      <main>
        <section title="Корзина">
          <CartList
            cart={this.state.cart}
            removeFromCart={this.removeFromCart}
            removeAllFromCart={this.removeAllFromCart}
          />
        </section>
        <section title="Мобильные телефоны">
          <PhoneList phones={data.phones} addToCart={this.addToCart} />
        </section>

        {/* <LaptopList laptops={data.laptops} /> */}
      </main>
    );
  }
}

export default Main;

// const Main = () => {
//     return (
//       <main>
//         <PhoneList phones={data.phones} />
//         {/* <LaptopList laptops={data.laptops} /> */}
//       </main>
//     );
// };

// export default Main;
