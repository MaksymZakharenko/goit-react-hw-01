import styled from "styled-components";

export const PhoneItemContainer = styled.li`

  width: 100%;
  padding: 5px 10px;
  /* background-color: yellow; */

  .itemWrapper {
    height: 500px;
    border: 1px solid grey;
    border-radius: 14px;
    padding: 10px;
    display: flex;
    flex-direction: column;
    /* justify-content: center; */
    align-items: center;
  }
  .itemTitle {
    text-align: center;
  }
  .itemImg {
    margin-top: 20px;
    width: 150px;
  }

  .itemColorList {
    display: flex;
    list-style: none;
  }

  @media (min-width: 768px) {
    width: 50%;
  }

  @media (min-width: 1024px) {
    width: 25%;
  }
`;

export const PhoneColorsListItem = styled.li`
  width: 20px;
  height: 20px;
  background-color: ${(props) => props.color};
  border: 1px solid grey;
  border-radius: 4px;
  margin: 10px;
  :not(:last-child) {
    margin-right: 5px;
  }
`;
