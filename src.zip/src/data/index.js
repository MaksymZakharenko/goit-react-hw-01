import header from "./header.json"
import laptops from "./laptops.json"
import phones from "./phones.json"


 const data = { header, laptops, phones };

 export default data;